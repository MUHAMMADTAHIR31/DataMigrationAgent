import java.io.*;
import org.w3c.dom.*;
import javax.xml.parsers.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.*;
import javax.xml.transform.stream.*;

public class AppendNode {
private static File inputFile = new File("input.xml");
public static void main(String[] args) {
try {

DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
Document document = documentBuilder.parse(inputFile);
Element documentElement = document.getDocumentElement();
Element textNode = document.createElement("name");
textNode.setTextContent("Rose");
Element textNode1 = document.createElement("address");
textNode1.setTextContent("Delhi");
Element nodeElement = document.createElement("student");
nodeElement.appendChild(textNode);
nodeElement.appendChild(textNode1);
documentElement.appendChild(nodeElement);
document.replaceChild(documentElement, documentElement);
Transformer tFormer =
TransformerFactory.newInstance().newTransformer();
tFormer.setOutputProperty(OutputKeys.METHOD, "xml");
Source source = new DOMSource(document);
Result result = new StreamResult(inputFile);
tFormer.transform(source, result);


} catch (Exception ex) {
System.out.println(ex);
}
}
}