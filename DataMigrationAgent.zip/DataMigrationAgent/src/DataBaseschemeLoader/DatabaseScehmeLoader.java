/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataBaseschemeLoader;

/**
 *
 * @author MOHAMMAD TAHIR
 */
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author MOHAMMAD TAHIR
 */

  public class DatabaseScehmeLoader {
    private static Connection con;
    private static Connection con_1;
    private static Statement st = null;
    static Scanner input = new Scanner(System.in);
    
    public static void main(String arg[])throws Exception{
        char str;
        do{
            System.out.print("Enter  The Original DataBase Name: ");
            String name= input.nextLine(); 
            init(name);
            System.out.println("Do You Want To Create Same Schema to new Database?Enter Y to Load DataBase");
            str=input.next().charAt(0);
            if(str=='Y'||str=='Y'){
                     System.out.println("Enter New Driver Name");
                    String dbname = input.next();
                    createDatabase(dbname);
            }
            
        }while(str!='N'||str!='n');    
    }
    
    
    private static void init(String name) throws Exception{
        
        try{
            String path=new java.io.File("db\\"+name+".accdb").getAbsolutePath();
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
           
            String url="jdbc:ucanaccess://"+path;
            con=DriverManager.getConnection(url);
        
        }catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
        } 
    }
        
    private static void createDatabase(String dbName) {
        try {
            String path=new java.io.File("db\\"+dbName+".accdb").getAbsolutePath();
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            String url="jdbc:ucanaccess://"+path;
            con_1 = DriverManager.getConnection(url);
            importDataBaseTable();
        } 
        catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } catch (Exception ex) {
            Logger.getLogger(DatabaseScehmeLoader.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public static void importDataBaseTable()throws Exception{
        try{
            DatabaseMetaData databaseMetaData =con.getMetaData();
            ResultSet result = databaseMetaData.getTables(null,null,"%",new String[]{"TABLE"});
            while(result.next()){
               importTableDetail(result.getString("TABLE_NAME"));
            }            
        }catch(Exception e){
          e.printStackTrace();
        }
    }
    
    public static void importTableDetail(String table)throws Exception{
        
        System.out.print(table);
        String query="select * from "+table;
        ResultSet result=null;
        
        try{
            st=con.createStatement();
            result=st.executeQuery(query);
            
            ResultSetMetaData metadata=result.getMetaData();
            int column=metadata.getColumnCount();
            
             String sql = "CREATE TABLE "+table+"(";
            Statement newstatment=null;
            
            for( int i=1; i<=column; i++){
              
                sql+=metadata.getColumnName(i)+" "+metadata.getColumnTypeName(i);
                sql+=","; 
            } 
            sql+=")";
            newstatment = con_1.createStatement(); 
            newstatment.executeUpdate(sql);
        }finally{
            if(st!=null)st.close();
        }
    }
       
}
