/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataBaseschemeLoader;

/**
 *
 * @author MOHAMMAD TAHIR
 */
import java.io.*;
import java.sql.*;
import org.w3c.dom.*;
import javax.xml.parsers.*;
public class InsertXMLData{
    private static Connection con;
    
    public static void main(String[] args) { 
        try {
            
            String path=new java.io.File("db\\school.accdb").getAbsolutePath();
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            String url="jdbc:ucanaccess://"+path;
            
            con=DriverManager.getConnection(url);
            Statement st=con.createStatement();
            
            DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
            Document doc = docBuilder.parse (new File("D:\\A Java Programming\\XML\\DataMigrationAgent\\record2.xml"));
            
            doc.getDocumentElement().normalize();
            System.out.println ("Root element of the doc is " + doc.getDocumentElement().getNodeName());
            NodeList listOfPersons = doc.getElementsByTagName("employee");
            
            for(int s=0; s<listOfPersons.getLength(); s++){
                Node firstPersonNode = listOfPersons.item(s);

                if(firstPersonNode.getNodeType() == Node.ELEMENT_NODE){
                    Element firstPersonElement = (Element)firstPersonNode;
                    NodeList nameList = firstPersonElement.getElementsByTagName("name");
                    Element nameElement =(Element)nameList.item(0);

                    NodeList textFNList = nameElement.getChildNodes();
                    String name=((Node)textFNList.item(0)).getNodeValue().trim();

                    NodeList addressList = firstPersonElement.getElementsByTagName("address");
                    Element addressElement =(Element)addressList.item(0);

                    NodeList textLNList = addressElement.getChildNodes();
                    String address= ((Node)textLNList.item(0)).getNodeValue().trim();

                  int i=st.executeUpdate("insert into student(std_name,fname) values('"+name+"','"+address+"')");
                }
            }
            System.out.println("Data is successfully inserted!");
            }catch (Exception err) {
            System.out.println(" " + err.getMessage ());
        }
    }
}