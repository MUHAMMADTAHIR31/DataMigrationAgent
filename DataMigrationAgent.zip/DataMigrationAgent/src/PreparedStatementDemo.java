
 
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
 
public class PreparedStatementDemo {
    
    static Connection con;
    public static void main(String args[])throws Exception{  
     try{
            String path=new java.io.File("db\\school.accdb").getAbsolutePath();
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            String url="jdbc:ucanaccess://"+path;
            con=DriverManager.getConnection(url);

            PreparedStatement ps=con.prepareStatement("insert into student values(?,?,?,?,?)");  
            BufferedReader br=new BufferedReader(new InputStreamReader(System.in));  

         do{  
                System.out.println("enter id:");  
                int id=Integer.parseInt(br.readLine());  
                
                System.out.println("enter Name:");  
                String name=br.readLine(); 
                
                System.out.println("enter Father Name:");  
                String fname=br.readLine();  
                
                System.out.println("enter Roll Number:");  
                String rollnumber=br.readLine();  
                
                System.out.println("enter surname:");  
                String surname=br.readLine();  

                ps.setInt(1,id);  
                ps.setString(2,name);  
                ps.setString(3,fname);  
                ps.setString(4,rollnumber);  
                ps.setString(5,surname);  
                int i=ps.executeUpdate();
                System.out.println(i+" records affected");  
                
                System.out.println("Do you want to continue: y/n");  
                String s=br.readLine();  

                if(s.startsWith("n")){  
                    break;  
                }  
            }while(true);
        }catch(Exception e){
         e.printStackTrace();
        }    
    con.close();  
    }
}