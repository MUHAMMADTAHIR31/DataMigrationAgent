/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PrintMetaData;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

/**
 *
 * @author MOHAMMAD TAHIR
 */
public class PrintMetaData {
   
    private static Connection con;
    private static Statement st = null;
    static Scanner input = new Scanner(System.in);
    
    public static void main(String arg[])throws Exception{
        System.out.print("Enter  The DataBase Name: ");
        String name= input.nextLine(); 
        init(name);
    }
    
    
    private static void init(String name) throws Exception{
        
        try{
            String path=new java.io.File("db\\"+name+".accdb").getAbsolutePath();
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
           
            String url="jdbc:ucanaccess://"+path;
            con=DriverManager.getConnection(url);
            if(createTable())
                System.out.println("Created table in given database...");
            else{
                System.out.println("Table Already Exits in given database...");
                //createTable();
            }   
        }catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            createDatabase(name);
            createTable();
        } 
    }
    
    private static void createDatabase(String dbName) {
        try {
            
            String path=new java.io.File("db\\"+dbName+".accdb").getAbsolutePath();
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            String url="jdbc:ucanaccess://"+path;
            con = DriverManager.getConnection(url);
            st = con.createStatement();
            String s1="CREATE DATABASE CLASSIFIED" + dbName; 
            st.executeUpdate(s1);
        } 
        catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }
    
    public static boolean createTable(){
        try{
            System.out.println("Creating table in given database...");
            
            System.out.print("Enter  The DataBase Name: ");
            String tableName= input.nextLine();
            st = con.createStatement();
            String sql = "CREATE TABLE "+tableName+" "+
                "(id COUNTER PRIMARY KEY ," +
                "std_name  VARCHAR(255), " + 
                " fname VARCHAR(255), " + 
                " surname VARCHAR(255), " + 
                " roll_number VARCHAR(255) )"; 
            st.executeUpdate(sql);
            return true;
        }catch(Exception e){
            e.printStackTrace();
            return false;
        }
    }
    
    public static void importDataBaseTable()throws Exception{
        
        try{
            DatabaseMetaData databaseMetaData =con.getMetaData();
            ResultSet result = databaseMetaData.getTables(null,null,"%",new String[]{"TABLE"});
            while(result.next()){
               importTableDetail(result.getString("TABLE_NAME"));
            }            
        }catch(Exception e){
          e.printStackTrace();
        }
    }
    
    public static void importTableDetail(String table)throws Exception{
        
        System.out.print(table);
        String query="select * from "+table;
        ResultSet result=null;
        
        try{
            st=con.createStatement();
            result=st.executeQuery(query);
            
            ResultSetMetaData metadata=result.getMetaData();
            int column=metadata.getColumnCount();
        
            for( int i=1; i<=column; i++)
                System.out.println(metadata.getColumnName(i)+"-----"+metadata.getColumnTypeName(i));
        }finally{
            if(st!=null)st.close();
        }
    }
}
