/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package XMLManager;

import java.io.File;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathFactory;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 *
 * @author MOHAMMAD TAHIR
 */
public class XMLManager {
    
    private static DocumentBuilderFactory dbFactory; 
    private static DocumentBuilder dBuilder;// = dbFactory.newDocumentBuilder();
    private static Document doc;
    private static final File inputFile = new File("input.xml");
    
    public static Vector getStudent()throws Exception {
            
       try{
            dbFactory = DocumentBuilderFactory.newInstance();
            dBuilder = dbFactory.newDocumentBuilder();
            doc = dBuilder.parse(inputFile);
            doc.getDocumentElement().normalize();
            NodeList nList = doc.getElementsByTagName("student");
                     
            Vector v=new Vector();
            for (int temp = 0; temp < nList.getLength(); temp++) {
                XmlBean bean = new  XmlBean();
                Node nNode = nList.item(temp);
                
                if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                    
                    Element eElement = (Element) nNode;
                    bean.setStd_id(eElement.getAttribute("stdid"));
                    bean.setName(eElement.getElementsByTagName("name").item(0).getTextContent());
                    bean.setFname(eElement.getElementsByTagName("fname").item(0).getTextContent());
                    bean.setSurname(eElement.getElementsByTagName("surname").item(0).getTextContent());
                    bean.setRoll_number(eElement.getElementsByTagName("rollnumber").item(0).getTextContent());
                    bean.setRemarks(eElement.getElementsByTagName("remarks").item(0).getTextContent());
                   
                    v.addElement(bean);
                }
            }
            return v;
        }finally {
        if(inputFile!=null)inputFile.exists();
        }//try
    }//getStudent
    
    public static int addStudent(String name, String fName, String surName,String rollnumber,String remarks)throws Exception{
        
        try{
            
            dbFactory =DocumentBuilderFactory.newInstance();         
            dBuilder = dbFactory.newDocumentBuilder();
            doc = dBuilder.parse(inputFile);
                
                // root element
            Element documentElement = doc.getDocumentElement();
                
            Element nodeElement = doc.createElement("student");
            Attr attr = doc.createAttribute("stdid");
      
            XPath xpath = XPathFactory.newInstance().newXPath();
            int id =Integer.parseInt(0+xpath.evaluate("/*/student[last()]/@stdid", doc));
           
            attr.setValue(String.valueOf(id+1));
            nodeElement.setAttributeNode(attr);
    
            if(name!=null){  
                Element nameNode = doc.createElement("name");
                nameNode.setTextContent(name);

                Element fnameNode = doc.createElement("fname");
                fnameNode.setTextContent(fName);

                Element surnameNode = doc.createElement("surname");
                surnameNode.setTextContent(surName);

                Element rollNumberNode = doc.createElement("rollnumber");
                rollNumberNode.setTextContent(rollnumber);

                Element remarksNode = doc.createElement("remarks");
                remarksNode.setTextContent(remarks);

                nodeElement.appendChild(nameNode);
                nodeElement.appendChild(fnameNode);
                nodeElement.appendChild(surnameNode);
                nodeElement.appendChild(rollNumberNode);
                nodeElement.appendChild(remarksNode);

                documentElement.appendChild(nodeElement);
                doc.replaceChild(documentElement, documentElement);
            }else{
            JOptionPane.showMessageDialog(null, "Please  Enter The Data..!!!!");
            }
            

                Source source = new DOMSource(doc);
                Transformer tFormer =TransformerFactory.newInstance().newTransformer();
                tFormer.setOutputProperty(OutputKeys.INDENT, "yes");

                Result result = new StreamResult(inputFile);
                tFormer.transform(source, result);

                StreamResult console = new StreamResult(System.out);
                tFormer.transform(source, console);
            }finally{
            if(inputFile!=null)inputFile.exists();
            }
            return 0;
        } 

        public static int updateStudent(String id,String name, String fName, String surName,String rollnumber,String remarks)throws Exception{

            try{
                dbFactory =DocumentBuilderFactory.newInstance();         
                dBuilder = dbFactory.newDocumentBuilder();
                doc = dBuilder.parse(inputFile);

                Element documentElement = doc.getDocumentElement();
                Element nodeElement = doc.createElement("student");
                NodeList nList = doc.getElementsByTagName("student");

                for (int i = 0; i < nList.getLength(); i++) {

                    Node node = nList.item(i);
                    if (node.getNodeType() == Element.ELEMENT_NODE) {

                        Element eElement = (Element) node;
                        if (eElement.getAttribute("stdid").equals(id)) {

                            // Remove All Element
                            node.getParentNode().removeChild(node);

                            // And ReCreate Same With Update  Values
                            Attr attr = doc.createAttribute("stdid");
                            attr.setValue(id);
                            nodeElement.setAttributeNode(attr);

                            Element nameNode = doc.createElement("name");
                            nameNode.setTextContent(name);

                            Element fnameNode = doc.createElement("fname");
                            fnameNode.setTextContent(fName);

                            Element surnameNode = doc.createElement("surname");
                            surnameNode.setTextContent(surName);

                            Element rollNumberNode = doc.createElement("rollnumber");
                            rollNumberNode.setTextContent(rollnumber);

                            Element remarksNode = doc.createElement("remarks");
                            remarksNode.setTextContent(remarks);

                            nodeElement.appendChild(nameNode);
                            nodeElement.appendChild(fnameNode);
                            nodeElement.appendChild(surnameNode);
                            nodeElement.appendChild(rollNumberNode);
                            nodeElement.appendChild(remarksNode);
                        }
                    }
                }
            documentElement.appendChild(nodeElement);
            doc.replaceChild(documentElement, documentElement);
                
            Source source = new DOMSource(doc);
                
            Transformer tFormer =TransformerFactory.newInstance().newTransformer();
            tFormer.setOutputProperty(OutputKeys.INDENT, "yes");
    
            Result result = new StreamResult(inputFile);
            tFormer.transform(source, result);

            StreamResult console = new StreamResult(System.out);
            tFormer.transform(source, console);  
        }finally{
            if(inputFile!=null)inputFile.exists();
        }
        return 0;
    }
    
    public static int deleteStudent(String id)throws Exception{
        
        try{
            dbFactory =DocumentBuilderFactory.newInstance();         
            dBuilder = dbFactory.newDocumentBuilder();
            doc = dBuilder.parse(inputFile);
                
            NodeList nList = doc.getElementsByTagName("student");
            for (int i = 0; i < nList.getLength(); i++) {
                Node node = nList.item(i);
                if (node.getNodeType() == Element.ELEMENT_NODE) {
                    Element eElement = (Element) node;
                    System.out.println(eElement.getAttribute("id"));
                    if (eElement.getAttribute("stdid").equals(id)) {
                        node.getParentNode().removeChild(node);
                    }
                }
            }
            
            Source source = new DOMSource(doc);
                
            Transformer tFormer =TransformerFactory.newInstance().newTransformer();
            tFormer.setOutputProperty(OutputKeys.INDENT, "yes");
    
            Result result = new StreamResult(inputFile);
            tFormer.transform(source, result);
                
            StreamResult console = new StreamResult(System.out);
            tFormer.transform(source, console);   
        }finally{
            if(inputFile!=null)inputFile.exists();
        }
        return 0;
    } 
}
