/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package XMLManager;

import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;

/**
 *
 * @author MOHAMMAD TAHIR
 */
public class XMLManagerJFrame extends javax.swing.JFrame {

    /**
     * Creates new form XMLManagerJFrame
     */
    public XMLManagerJFrame() {
        initComponents();
        getStudent();
    }
    
    private void getStudent(){
        
     try{
            Vector v=XMLManager.getStudent();
            rollNumberjList.setListData(v);
        }catch(Exception e){
            e.printStackTrace();
            JOptionPane.showMessageDialog(this,"Error"+e.getMessage());
        }
    }
    
    private void clear(){
        std_idTextField.setText("");
        std_nameTextField.setText("");
        fnameTextField.setText("");
        surnameTextField.setText("");
        rollNumberTextField.setText("");
        remarksTextArea.setText("");
    }
    
    private void addStudent(){

        String name=std_nameTextField.getText();
        String fname=fnameTextField.getText();
        String surname=surnameTextField.getText();
        String rollnumber=rollNumberTextField.getText();
        String remarks=remarksTextArea.getText();
     
        try{
            int rows=XMLManager.addStudent(name,  fname,  surname, rollnumber, remarks);
            if(rows>=0){
                JOptionPane.showMessageDialog(this,(1+rows)+" Record Added");
                
                getStudent();
                clear();
            }
        }catch(Exception e){
            e.printStackTrace();
            JOptionPane.showMessageDialog(this,"Error: "+e.getMessage()); 
        }        
    }
    
    private void updateStudent(){
        
        String stdId=std_idTextField.getText();
        String name=std_nameTextField.getText();
        String fname=fnameTextField.getText();
        String surname=surnameTextField.getText();
        String rollnumber=rollNumberTextField.getText();
        String remarks=remarksTextArea.getText();
                   
        try{
            int rows=XMLManager.updateStudent(stdId, name,  fname,  surname, rollnumber, remarks);
            if(rows>=0){
                JOptionPane.showMessageDialog(this,(1+rows)+" Record Update");
                getStudent();
                clear();
            }
        }catch(Exception e){
            e.printStackTrace();
            JOptionPane.showMessageDialog(this,"Error: "+e.getMessage()); 
        }        
    }
    
    private void deleteStudent(){
      try{
        
            int[] size = rollNumberjList.getSelectedIndices();
            rollNumberjList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
            
            int rows=0;
            for(int i=0; i<size.length; i++){
                XmlBean bean=(XmlBean)rollNumberjList.getModel().getElementAt(size[i]);
                if(bean==null)continue;
              
                rows+=XMLManager.deleteStudent(bean.getStd_id());
            }//end for
          
            if(rows>=0){
                JOptionPane.showMessageDialog(this,(1+rows)+" record Deleted");
                getStudent(); clear();
            }
        }catch(Exception ee){
            ee.printStackTrace();
            JOptionPane.showMessageDialog(this,"Error: "+ee.getMessage());                 
        }
    }//end method
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        rollNumberjList = new javax.swing.JList();
        rollNumberTextField = new javax.swing.JTextField();
        std_idTextField = new javax.swing.JTextField();
        std_nameTextField = new javax.swing.JTextField();
        fnameTextField = new javax.swing.JTextField();
        surnameTextField = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        exitButton = new javax.swing.JButton();
        addButton = new javax.swing.JButton();
        deleteButton = new javax.swing.JButton();
        updateButton = new javax.swing.JButton();
        clearButton = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        remarksTextArea = new javax.swing.JTextArea();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTextArea2 = new javax.swing.JTextArea();
        jLabel9 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        jLabel1.setText("XML Manager");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 10, 160, 40));

        rollNumberjList.addListSelectionListener(new javax.swing.event.ListSelectionListener() {
            public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
                rollNumberjListValueChanged(evt);
            }
        });
        jScrollPane1.setViewportView(rollNumberjList);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 110, 190, 340));
        jPanel1.add(rollNumberTextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 300, 260, 40));

        std_idTextField.setEditable(false);
        std_idTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                std_idTextFieldActionPerformed(evt);
            }
        });
        jPanel1.add(std_idTextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 110, 100, 30));
        jPanel1.add(std_nameTextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 150, 260, 40));

        fnameTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fnameTextFieldActionPerformed(evt);
            }
        });
        jPanel1.add(fnameTextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 200, 260, 40));

        surnameTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                surnameTextFieldActionPerformed(evt);
            }
        });
        jPanel1.add(surnameTextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 250, 260, 40));

        jLabel2.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel2.setText("Roll Number");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 80, 90, 20));

        jLabel3.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel3.setText("Student ID");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 110, 80, 30));

        jLabel4.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel4.setText("Student Name");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 160, 100, 20));

        jLabel5.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel5.setText("Father's Name");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 210, 110, 20));

        jLabel6.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel6.setText("Surname");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 260, 70, 20));

        exitButton.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        exitButton.setText("Exit");
        exitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitButtonActionPerformed(evt);
            }
        });
        jPanel1.add(exitButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 460, 110, 40));

        addButton.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        addButton.setText("ADD");
        addButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addButtonActionPerformed(evt);
            }
        });
        jPanel1.add(addButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 460, 70, 40));

        deleteButton.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        deleteButton.setText("Delete");
        deleteButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteButtonActionPerformed(evt);
            }
        });
        jPanel1.add(deleteButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 460, -1, 40));

        updateButton.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        updateButton.setText("Update");
        updateButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateButtonActionPerformed(evt);
            }
        });
        jPanel1.add(updateButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 460, -1, 40));

        clearButton.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        clearButton.setText("Clear");
        clearButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearButtonActionPerformed(evt);
            }
        });
        jPanel1.add(clearButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 460, 80, 40));

        jLabel8.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel8.setText("Remarks");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 350, 70, 20));

        remarksTextArea.setColumns(20);
        remarksTextArea.setRows(5);
        jScrollPane2.setViewportView(remarksTextArea);

        jPanel1.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 350, 260, -1));

        jTextArea2.setColumns(20);
        jTextArea2.setRows(5);
        jScrollPane3.setViewportView(jTextArea2);

        jPanel1.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 350, 260, -1));

        jLabel9.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel9.setText("Roll Number");
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 310, 90, 20));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 683, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 614, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void surnameTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_surnameTextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_surnameTextFieldActionPerformed

    private void fnameTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fnameTextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fnameTextFieldActionPerformed

    private void addButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addButtonActionPerformed
       addStudent();
    }//GEN-LAST:event_addButtonActionPerformed

    private void rollNumberjListValueChanged(javax.swing.event.ListSelectionEvent evt) {//GEN-FIRST:event_rollNumberjListValueChanged
        XmlBean bean=(XmlBean)rollNumberjList.getSelectedValue();
        if(bean==null)return;
        
        std_idTextField.setText(bean.getStd_id());
        std_nameTextField.setText(bean.getName());
        fnameTextField.setText(bean.getFname());
        surnameTextField.setText(bean.getSurname());
        rollNumberTextField.setText(bean.getRoll_number());
        remarksTextArea.setText(bean.getRemarks());
    }//GEN-LAST:event_rollNumberjListValueChanged

    private void clearButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearButtonActionPerformed
        clear();
    }//GEN-LAST:event_clearButtonActionPerformed

    private void exitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitButtonActionPerformed
       System.exit(0);
    }//GEN-LAST:event_exitButtonActionPerformed

    private void updateButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateButtonActionPerformed
        updateStudent();
    }//GEN-LAST:event_updateButtonActionPerformed

    private void deleteButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteButtonActionPerformed
       deleteStudent();
    }//GEN-LAST:event_deleteButtonActionPerformed

    private void std_idTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_std_idTextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_std_idTextFieldActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(XMLManagerJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(XMLManagerJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(XMLManagerJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(XMLManagerJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new XMLManagerJFrame().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addButton;
    private javax.swing.JButton clearButton;
    private javax.swing.JButton deleteButton;
    private javax.swing.JButton exitButton;
    private javax.swing.JTextField fnameTextField;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTextArea jTextArea2;
    private javax.swing.JTextArea remarksTextArea;
    private javax.swing.JTextField rollNumberTextField;
    private javax.swing.JList rollNumberjList;
    private javax.swing.JTextField std_idTextField;
    private javax.swing.JTextField std_nameTextField;
    private javax.swing.JTextField surnameTextField;
    private javax.swing.JButton updateButton;
    // End of variables declaration//GEN-END:variables
}
