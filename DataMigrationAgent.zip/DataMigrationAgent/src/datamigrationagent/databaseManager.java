/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package datamigrationagent;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

/**
 *
 * @author MOHAMMAD TAHIR
 */
public class databaseManager {
     
    private static Connection con;
      
    static{
	try{
            init();            
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    private static void init() throws Exception{
	
	Class.forName(DataMigrationAgentJFrame.classTextField.getText());
        con=DriverManager.getConnection(DataMigrationAgentJFrame.urlTextField.getText());
    }  
    
    public static int importTable(String roll_number,String std_name,String fname,String surname)throws Exception{
        
        String query="insert into student (roll_number,std_name,fname,surname) values ('"+roll_number+"','"+std_name+"','"+fname+"','"+surname+"') ";
        System.out.println(query);
               
        Statement st=null;
               
        try{
            st=con.createStatement();
            int rows=st.executeUpdate(query);
                return rows; 
            }finally{
                if(st!=null)st.close();
            }
    }
}
